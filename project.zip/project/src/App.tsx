import React, { useState, useEffect, useRef } from 'react';
import { Home, Search as SearchIcon, PlusSquare, Play, Send, User } from 'lucide-react';
import Typed from 'typed.js';
import Feed from './components/Feed';
import Messages from './components/Messages';
import Profile from './components/Profile';
import Search from './components/Search';

function App() {
  const [currentPage, setCurrentPage] = useState<'feed' | 'messages' | 'profile' | 'search'>('feed');
  const titleRef = useRef(null);

  useEffect(() => {
    const typed = new Typed(titleRef.current, {
      strings: ['iiitverse'],
      typeSpeed: 100,
      backSpeed: 50,
      backDelay: 3000,
      loop: true,
      showCursor: false,
    });

    return () => {
      typed.destroy();
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-blue-50 to-green-50">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/70 backdrop-blur-lg border-b border-green-100 z-50">
        <div className="max-w-xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 
            ref={titleRef}
            className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-700 bg-clip-text text-transparent font-['Playfair_Display']"
          />
          <div className="flex items-center space-x-4">
            <button 
              className="p-2 rounded-full border border-green-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300"
              onClick={() => setCurrentPage('messages')}
            >
              <Send className={`w-5 h-5 ${currentPage === 'messages' ? 'text-blue-700' : 'text-gray-500'}`} />
            </button>
            <button className="px-4 py-2 rounded-full border border-green-200 bg-gradient-to-r from-green-500 to-blue-600 text-white text-sm font-medium hover:shadow-lg hover:scale-105 transition-all duration-300">
              Add Post
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-20 pb-20">
        {currentPage === 'feed' && <Feed />}
        {currentPage === 'messages' && <Messages onBack={() => setCurrentPage('feed')} />}
        {currentPage === 'profile' && <Profile onBack={() => setCurrentPage('feed')} />}
        {currentPage === 'search' && <Search onBack={() => setCurrentPage('feed')} />}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/70 backdrop-blur-lg border-t border-green-100">
        <div className="max-w-xl mx-auto px-4 py-3 flex justify-between items-center">
          <button 
            className="p-2 rounded-full border border-green-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300"
            onClick={() => setCurrentPage('feed')}
          >
            <Home className={`w-5 h-5 ${currentPage === 'feed' ? 'text-blue-700' : 'text-gray-500'}`} />
          </button>
          <button 
            className="p-2 rounded-full border border-green-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300"
            onClick={() => setCurrentPage('search')}
          >
            <SearchIcon className={`w-5 h-5 ${currentPage === 'search' ? 'text-blue-700' : 'text-gray-500'}`} />
          </button>
          <button className="p-2 rounded-full border border-green-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300">
            <PlusSquare className="w-5 h-5 text-gray-500" />
          </button>
          <button className="p-2 rounded-full border border-green-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300">
            <Play className="w-5 h-5 text-gray-500" />
          </button>
          <button 
            onClick={() => setCurrentPage('profile')}
            className="w-7 h-7 rounded-full border-2 border-green-200 hover:border-blue-400 transition-all duration-300 overflow-hidden"
          >
            <img
              src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150"
              alt="profile"
              className="w-full h-full object-cover"
            />
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;