import React from 'react';
import { Search, ArrowLeft } from 'lucide-react';

const messages = [
  {
    id: 1,
    username: 'sarah_designs',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    lastMessage: 'Thanks for the feedback! 🙌',
    time: '2m ago',
    unread: true
  },
  {
    id: 2,
    username: 'mike.photo',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    lastMessage: 'Let\'s collaborate on the next project',
    time: '1h ago',
    unread: false
  },
  {
    id: 3,
    username: 'travel_lisa',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    lastMessage: 'The photos look amazing!',
    time: '3h ago',
    unread: true
  },
  {
    id: 4,
    username: 'alex.adventures',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    lastMessage: 'See you tomorrow at the meetup!',
    time: '1d ago',
    unread: false
  }
];

function Messages() {
  return (
    <div className="max-w-xl mx-auto">
      {/* Messages Header */}
      <div className="bg-white/60 backdrop-blur-lg p-4 mb-4 rounded-xl border border-green-100 shadow-sm">
        <div className="flex items-center space-x-4">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
          <div className="flex-1">
            <h2 className="text-lg font-semibold">Messages</h2>
            <p className="text-sm text-gray-500">4 unread messages</p>
          </div>
        </div>
        <div className="mt-4 relative">
          <input
            type="text"
            placeholder="Search messages..."
            className="w-full px-4 py-2 pl-10 bg-white/50 border border-green-100 rounded-full focus:outline-none focus:border-blue-400 transition-colors"
          />
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Messages List */}
      <div className="space-y-2">
        {messages.map((message) => (
          <div
            key={message.id}
            className="bg-white/60 backdrop-blur-lg p-4 rounded-xl border border-green-100 shadow-sm flex items-center space-x-4 hover:bg-white/80 transition-colors cursor-pointer"
          >
            <div className="relative">
              <img
                src={message.avatar}
                alt={message.username}
                className="w-12 h-12 rounded-full object-cover border border-green-200"
              />
              {message.unread && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h3 className="font-semibold text-sm">{message.username}</h3>
                <span className="text-xs text-gray-500">{message.time}</span>
              </div>
              <p className={`text-sm ${message.unread ? 'text-gray-800 font-medium' : 'text-gray-500'}`}>
                {message.lastMessage}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Messages;