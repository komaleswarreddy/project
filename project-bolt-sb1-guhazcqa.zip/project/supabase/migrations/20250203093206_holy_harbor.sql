/*
  # Fix Authentication and RLS Policies

  1. Changes
    - Update profiles RLS policies to allow new user creation
    - Fix profile insertion policy for new signups
    - Add missing policies for profile updates
  
  2. Security
    - Maintain secure access control while allowing necessary operations
    - Ensure new users can create their profiles during signup
*/

-- Drop existing policies on profiles table
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Create new policies for profiles table
CREATE POLICY "Profiles are viewable by authenticated users"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Ensure RLS is enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;