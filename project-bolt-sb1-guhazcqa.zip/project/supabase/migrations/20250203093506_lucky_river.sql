/*
  # Fix profile policies for better security

  1. Changes
    - Update profile policies to be more secure and handle edge cases
    - Add policy for checking username uniqueness
    - Ensure proper access control for profile operations

  2. Security
    - Enable RLS
    - Add specific policies for each operation
    - Ensure proper user authentication checks
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Profiles are viewable by authenticated users" ON profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;

-- Create new policies with better security
CREATE POLICY "Authenticated users can view profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own profile once"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = id
    AND NOT EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create unique index for username to ensure case-insensitive uniqueness
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique_idx ON profiles (LOWER(username));