export interface Profile {
  id: string;
  username: string;
  avatar_url?: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  created_at: string;
  updated_at: string;
  participants: Profile[];
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content?: string;
  image_url?: string;
  created_at: string;
  updated_at: string;
  sender?: Profile;
}