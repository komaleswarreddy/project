import React, { useEffect, useState, useRef } from 'react';
import { useChatStore } from '../store/chatStore';
import { useAuthStore } from '../store/authStore';
import { supabase } from '../lib/supabase';
import { Image, Send } from 'lucide-react';

export function Chat() {
  const { user } = useAuthStore();
  const {
    conversations,
    currentConversation,
    messages,
    setConversations,
    setCurrentConversation,
    setMessages,
    sendMessage,
  } = useChatStore();

  const [newMessage, setNewMessage] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetchConversations = async () => {
      const { data, error } = await supabase
        .from('conversation_participants')
        .select(`
          conversation:conversations(
            id,
            created_at,
            updated_at,
            conversation_participants(profiles(*))
          )
        `)
        .eq('profile_id', user?.id);

      if (error) {
        console.error('Error fetching conversations:', error);
        return;
      }

      const formattedConversations = data.map((item: any) => ({
        ...item.conversation,
        participants: item.conversation.conversation_participants.map(
          (cp: any) => cp.profiles
        ),
      }));

      setConversations(formattedConversations);
    };

    if (user) {
      fetchConversations();
    }
  }, [user]);

  useEffect(() => {
    if (currentConversation) {
      const fetchMessages = async () => {
        const { data, error } = await supabase
          .from('messages')
          .select('*, sender:profiles(*)')
          .eq('conversation_id', currentConversation.id)
          .order('created_at', { ascending: true });

        if (error) {
          console.error('Error fetching messages:', error);
          return;
        }

        setMessages(data);
      };

      fetchMessages();

      const subscription = supabase
        .channel(`conversation:${currentConversation.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${currentConversation.id}`,
          },
          (payload) => {
            setMessages((current) => [...current, payload.new]);
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [currentConversation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() && !imageFile) return;

    try {
      let imageUrl;
      if (imageFile) {
        const { data, error } = await supabase.storage
          .from('chat-images')
          .upload(`${Date.now()}-${imageFile.name}`, imageFile);

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from('chat-images')
          .getPublicUrl(data.path);

        imageUrl = publicUrl;
      }

      await sendMessage(newMessage, imageUrl);
      setNewMessage('');
      setImageFile(null);
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleImageClick = () => {
    fileInputRef.current?.click();
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-1/4 bg-white border-r border-gray-200 p-4">
        <h2 className="text-xl font-semibold mb-4">Conversations</h2>
        <div className="space-y-2">
          {conversations.map((conversation) => (
            <button
              key={conversation.id}
              onClick={() => setCurrentConversation(conversation)}
              className={`w-full p-3 rounded-lg text-left ${
                currentConversation?.id === conversation.id
                  ? 'bg-blue-50 text-blue-600'
                  : 'hover:bg-gray-50'
              }`}
            >
              {conversation.participants
                .filter((p) => p.id !== user?.id)
                .map((p) => p.username)
                .join(', ')}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {currentConversation ? (
          <>
            {/* Messages */}
            <div className="flex-1 p-4 overflow-y-auto">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.sender_id === user?.id ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-sm rounded-lg p-3 ${
                        message.sender_id === user?.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      {message.content && <p>{message.content}</p>}
                      {message.image_url && (
                        <img
                          src={message.image_url}
                          alt="Shared image"
                          className="mt-2 rounded-lg max-w-xs"
                        />
                      )}
                      <p className="text-xs mt-1 opacity-75">
                        {new Date(message.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* Input Area */}
            <form
              onSubmit={handleSendMessage}
              className="p-4 border-t border-gray-200 bg-white"
            >
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={handleImageClick}
                  className="p-2 text-gray-500 hover:text-blue-500"
                >
                  <Image className="w-6 h-6" />
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageChange}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="submit"
                  className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Send className="w-6 h-6" />
                </button>
              </div>
              {imageFile && (
                <div className="mt-2 p-2 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">
                    Selected image: {imageFile.name}
                  </p>
                </div>
              )}
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-gray-500">Select a conversation to start chatting</p>
          </div>
        )}
      </div>
    </div>
  );
}