import React, { useEffect } from 'react';
import { Auth } from './components/Auth';
import { Chat } from './components/Chat';
import { useAuthStore } from './store/authStore';
import { supabase } from './lib/supabase';

function App() {
  const { user, setUser, loading } = useAuthStore();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle()  // Use maybeSingle instead of single to handle missing profiles
          .then(({ data, error }) => {
            if (error) {
              console.error('Error fetching profile:', error);
              setUser(null);
              return;
            }
            setUser(data);
          });
      } else {
        setUser(null);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle()  // Use maybeSingle instead of single
          .then(({ data, error }) => {
            if (error) {
              console.error('Error fetching profile:', error);
              setUser(null);
              return;
            }
            setUser(data);
          });
      } else {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return <div className="min-h-screen">{user ? <Chat /> : <Auth />}</div>;
}

export default App;