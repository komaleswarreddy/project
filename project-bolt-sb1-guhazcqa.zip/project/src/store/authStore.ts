import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Profile } from '../types/database';

interface AuthState {
  user: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, username: string) => Promise<void>;
  signOut: () => Promise<void>;
  setUser: (user: Profile | null) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signIn: async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
  },
  signUp: async (email, password, username) => {
    // First check if username is available using a proper query
    const { count, error: countError } = await supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .eq('username', username);

    if (countError) throw countError;
    if (count && count > 0) {
      throw new Error('Username already taken');
    }

    // Attempt to sign up the user
    const { error: signUpError, data } = await supabase.auth.signUp({
      email,
      password,
    });

    if (signUpError) throw signUpError;

    if (data.user) {
      try {
        const { error: profileError } = await supabase
          .from('profiles')
          .insert([
            {
              id: data.user.id,
              username,
              updated_at: new Date().toISOString(),
            },
          ])
          .select()
          .single();

        if (profileError) {
          // If profile creation fails, clean up by attempting to delete the auth user
          await supabase.auth.admin.deleteUser(data.user.id);
          throw profileError;
        }
      } catch (error) {
        // If any error occurs during profile creation, attempt to clean up
        await supabase.auth.admin.deleteUser(data.user.id);
        throw error;
      }
    }
  },
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null });
  },
  setUser: (user) => set({ user, loading: false }),
}));