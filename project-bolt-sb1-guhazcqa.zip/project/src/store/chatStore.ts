import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Conversation, Message, Profile } from '../types/database';

interface ChatState {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  messages: Message[];
  loading: boolean;
  setConversations: (conversations: Conversation[]) => void;
  setCurrentConversation: (conversation: Conversation | null) => void;
  setMessages: (messages: Message[]) => void;
  sendMessage: (content: string, imageUrl?: string) => Promise<void>;
  createConversation: (participantIds: string[]) => Promise<void>;
}

export const useChatStore = create<ChatState>((set, get) => ({
  conversations: [],
  currentConversation: null,
  messages: [],
  loading: true,
  setConversations: (conversations) => set({ conversations }),
  setCurrentConversation: (conversation) => set({ currentConversation: conversation }),
  setMessages: (messages) => set({ messages }),
  sendMessage: async (content, imageUrl) => {
    const conversation = get().currentConversation;
    if (!conversation) return;

    const { error } = await supabase.from('messages').insert([{
      conversation_id: conversation.id,
      content,
      image_url: imageUrl,
    }]);

    if (error) throw error;
  },
  createConversation: async (participantIds) => {
    const { data: conversation, error: convError } = await supabase
      .from('conversations')
      .insert([{}])
      .select()
      .single();

    if (convError) throw convError;

    const participants = participantIds.map((id) => ({
      conversation_id: conversation.id,
      profile_id: id,
    }));

    const { error: partError } = await supabase
      .from('conversation_participants')
      .insert(participants);

    if (partError) throw partError;
  },
}));